<?php
// src/OC/PlatformBundle/Purger/Advert.php

namespace OC\PlatformBundle\Purger;


use OC\PlatformBundle\Entity\AdvertSkill;
use OC\PlatformBundle\Entity\Application;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityManager;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\Container;


class Advert
{
    private $days;
    protected $em;
    private $container;

    public function __construct($days, $em, $container)
    {
      $this->days = $days;
      $this->em = $em; 
      $this->container = $container;
      
    }

    public function purge($days)
    {
        
      
             $listAdverts = $this
             ->getDoctrine()
             ->getManager()
             ->getRepository('OCPlatformBundle:Advert')
             ->getAndDeleteAdverts($days)
           ;

           foreach ($listAdverts as $advert) {
            foreach ($advert->getApplications() as $application) {
            $advert->removeApplication($application);
            
          }
        }
        foreach ($listAdverts as $advert) {
          foreach ($advert->getAdvertskills() as $advertskill) {
          $advert->removeAdvertskill($advertskill);
          
          }
        }
        
          foreach ($listAdverts as $advert) {
            foreach ($advert->getCategories() as $category) {
            $advert->removeCategory($category); 
            
            }
          }
          
          // On déclenche la modification
          
          $em->flush();
          
    }
 
}
